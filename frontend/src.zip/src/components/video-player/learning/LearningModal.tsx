"use client";

import { type KeyboardEvent, useEffect, useRef } from "react";
import { LoaderCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SenseNavigation } from "@/components/video-player/learning/SenseNavigation";
import { SenseView } from "@/components/video-player/learning/SenseView";
import type { LearningItem } from "@/components/video-player/learning/learningItems";

export function LearningModal({
  items,
  activeIndex,
  learnedSenseIds,
  isSubmitting,
  error,
  onClose,
  onPrevious,
  onNext,
  onLearn,
}: {
  items: LearningItem[];
  activeIndex: number;
  learnedSenseIds: ReadonlySet<number>;
  isSubmitting: boolean;
  error: string | null;
  onClose: () => void;
  onPrevious: () => void;
  onNext: () => void;
  onLearn: (senseId: number) => void;
}) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const item = items[activeIndex];
  useEffect(() => {
    previousFocus.current =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    dialogRef.current?.focus();
    return () => previousFocus.current?.focus();
  }, []);
  if (!item) return null;
  const learned = learnedSenseIds.has(item.sense.id);
  function keyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      onClose();
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = Array.from(
      dialogRef.current?.querySelectorAll<HTMLElement>(
        "button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex='-1'])",
      ) ?? [],
    );
    if (!focusable.length) {
      event.preventDefault();
      return;
    }
    const first = focusable[0],
      last = focusable.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
  return (
    <div
      className="absolute inset-0 z-40 flex items-center justify-center bg-black/75 p-3 sm:p-6"
      data-player-interactive="true"
      onClick={(e) => e.stopPropagation()}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="learning-modal-title"
        tabIndex={-1}
        onKeyDown={keyDown}
        className="max-h-[92%] w-full max-w-2xl overflow-y-auto rounded-2xl bg-background p-5 text-foreground shadow-2xl sm:p-6"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Learn from this subtitle
            </p>
            <h2
              id="learning-modal-title"
              className="mt-1 truncate text-lg font-semibold"
            >
              {item.mappingLabel}
            </h2>
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={onClose}
            aria-label="Close learning dialog"
          >
            <X className="size-5" />
          </Button>
        </div>
        <div className="my-5 border-t" />
        <SenseView sense={item.sense} learned={learned} />
        {error ? (
          <p
            role="alert"
            className="mt-5 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {error}
          </p>
        ) : null}
        <div className="mt-6">
          <Button
            type="button"
            disabled={isSubmitting || learned}
            onClick={() => onLearn(item.sense.id)}
          >
            {isSubmitting ? (
              <LoaderCircle className="size-4 animate-spin" />
            ) : null}
            {learned
              ? "Already learned"
              : isSubmitting
                ? "Saving…"
                : "Mark this sense learned"}
          </Button>
        </div>
        <div className="mt-6 border-t pt-4">
          <SenseNavigation
            index={activeIndex}
            count={items.length}
            onPrevious={onPrevious}
            onNext={onNext}
          />
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Enter closes · Left/Right moves between senses
        </p>
      </div>
    </div>
  );
}
