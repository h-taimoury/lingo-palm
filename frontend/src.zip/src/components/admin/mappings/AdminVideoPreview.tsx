"use client"

import { useEffect, useRef, useState } from "react"
import Hls from "hls.js"
import { getMediaSourceKind } from "@/components/video-player/core/mediaSource"

export function AdminVideoPreview({ source }: { source: string }) {
  const ref = useRef<HTMLVideoElement>(null); const [error, setError] = useState<string | null>(null)
  useEffect(() => { const video = ref.current; if (!video || !source) return; setError(null); let hls: Hls | null = null; const onError = () => setError("The preview could not play this source."); video.addEventListener("error", onError); if (getMediaSourceKind(source) === "hls" && !video.canPlayType("application/vnd.apple.mpegurl")) { if (Hls.isSupported()) { hls = new Hls(); hls.on(Hls.Events.ERROR, (_event, data) => { if (data.fatal) setError("The HLS preview encountered a fatal error.") }); hls.loadSource(source); hls.attachMedia(video) } else setError("HLS is not supported by this browser.") } else { video.src = source; video.load() } return () => { video.removeEventListener("error", onError); hls?.destroy(); video.removeAttribute("src"); video.load() } }, [source])
  return <div>{<video ref={ref} controls playsInline preload="metadata" className="aspect-video w-full rounded-xl bg-black object-contain" />}{error ? <p className="mt-2 text-sm text-destructive">{error}</p> : null}</div>
}
