"use client"

import Link from "next/link"
import { useEffect, useMemo, useState } from "react"
import { LoaderCircle, Search, Trash2, X } from "lucide-react"

import { useUnsavedChangesWarning } from "@/components/admin/mappings/useUnsavedChangesWarning"
import { ApiErrorMessage } from "@/components/shared/ApiErrorMessage"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { apiClient } from "@/lib/api/client"
import { publicEnv } from "@/lib/env"
import { buildSubtitleMappingIndex, createSubtitleTokenKey, loadVtt, tokenToSubtitleWordInput } from "@/lib/subtitles"
import { cn } from "@/lib/utils"
import type { PaginatedResponse } from "@/types/api/common"
import type { CreateSubtitleWordRequest, CreateWordSenseMappingRequest, SectionDetail, SubtitleWord, UpdateWordSenseMappingRequest, WordSenseMapping } from "@/types/api/courses"
import type { Sense, SenseSummary } from "@/types/api/dictionary"
import type { SubtitleCue, SubtitleToken } from "@/types/subtitles"

const mappingColors = [
  "bg-sky-200 text-sky-950 ring-sky-500/40",
  "bg-emerald-200 text-emerald-950 ring-emerald-500/40",
  "bg-violet-200 text-violet-950 ring-violet-500/40",
  "bg-amber-200 text-amber-950 ring-amber-500/40",
  "bg-rose-200 text-rose-950 ring-rose-500/40",
  "bg-cyan-200 text-cyan-950 ring-cyan-500/40",
] as const

function mappingColor(id: number) { return mappingColors[Math.abs(id) % mappingColors.length] }
function wordKey(word: SubtitleWord) { return createSubtitleTokenKey({ cueId: word.cue_id, word: word.word, positionInCue: word.position_in_cue }) }
function sameSet(a: Set<string>, b: Set<string>) { return a.size === b.size && [...a].every((item) => b.has(item)) }
function sameIds(a: Map<number, SenseSummary>, ids: number[]) { return a.size === ids.length && ids.every((id) => a.has(id)) }

export function MappingEditor({ section }: { section: SectionDetail }) {
  const [cues, setCues] = useState<SubtitleCue[]>([]); const [mappings, setMappings] = useState(section.word_sense_mappings); const [loadError, setLoadError] = useState<unknown>(null); const [actionError, setActionError] = useState<unknown>(null); const [busy, setBusy] = useState(false)
  const [activeId, setActiveId] = useState<number | null>(null); const [selectedKeys, setSelectedKeys] = useState<Set<string>>(() => new Set()); const [selectedSenses, setSelectedSenses] = useState<Map<number, SenseSummary>>(() => new Map())
  const [search, setSearch] = useState(""); const [results, setResults] = useState<Sense[]>([]); const [searching, setSearching] = useState(false)

  useEffect(() => { const abort = new AbortController(); void loadVtt(section.subtitle_file, abort.signal).then((parsed) => { setCues(parsed.cues); setLoadError(null) }).catch((error) => { if (!abort.signal.aborted) setLoadError(error) }); return () => abort.abort() }, [section.subtitle_file])
  useEffect(() => { const query = search.trim(); if (query.length < 2) { setResults([]); setSearching(false); return } const abort = new AbortController(); const timer = window.setTimeout(() => { setSearching(true); void apiClient.get<PaginatedResponse<Sense>>(`/api/dictionary/senses/?search=${encodeURIComponent(query)}&page=1`, { signal: abort.signal }).then((data) => setResults(data.results)).catch((error) => { if (!abort.signal.aborted) setActionError(error) }).finally(() => { if (!abort.signal.aborted) setSearching(false) }) }, 300); return () => { window.clearTimeout(timer); abort.abort() } }, [search])

  const active = mappings.find((mapping) => mapping.id === activeId) ?? null
  const originalKeys = useMemo(() => new Set(active?.subtitle_words.map(wordKey) ?? []), [active])
  const originalSenseIds = active?.senses.map((sense) => sense.id) ?? []
  const dirty = active ? !sameSet(selectedKeys, originalKeys) || !sameIds(selectedSenses, originalSenseIds) : selectedKeys.size > 0 || selectedSenses.size > 0
  useUnsavedChangesWarning(dirty)

  const mappingIndexResult = useMemo(() => {
    try {
      return { index: buildSubtitleMappingIndex(mappings), error: null as unknown }
    } catch (error) {
      return { index: new Map<string, WordSenseMapping>(), error }
    }
  }, [mappings])
  const mappingIndex = mappingIndexResult.index
  const effectiveLoadError = loadError ?? mappingIndexResult.error
  const tokenLookup = useMemo(() => { const map = new Map<string, { token: SubtitleToken; cue: SubtitleCue }>(); cues.forEach((cue) => cue.tokens.forEach((token) => map.set(token.key, { token, cue }))); return map }, [cues])

  function resetWorking() { setActiveId(null); setSelectedKeys(new Set()); setSelectedSenses(new Map()); setSearch(""); setResults([]); setActionError(null) }
  function openMapping(mapping: WordSenseMapping) { if (dirty && !window.confirm("Discard your current unsaved mapping changes?")) return; setActiveId(mapping.id); setSelectedKeys(new Set(mapping.subtitle_words.map(wordKey))); setSelectedSenses(new Map(mapping.senses.map((sense) => [sense.id, sense]))); setSearch(""); setActionError(null) }
  function clickToken(token: SubtitleToken) { const existing = mappingIndex.get(token.key); if (existing && existing.id !== activeId) { openMapping(existing); return } setSelectedKeys((current) => { const next = new Set(current); next.has(token.key) ? next.delete(token.key) : next.add(token.key); return next }) }
  function toggleSense(sense: SenseSummary) { setSelectedSenses((current) => { const next = new Map(current); next.has(sense.id) ? next.delete(sense.id) : next.set(sense.id, sense); return next }) }

  async function reload() { const fresh = await apiClient.get<SectionDetail>(`/api/courses/sections/${section.id}/`); setMappings(fresh.word_sense_mappings); return fresh.word_sense_mappings }
  async function save() {
    if (!selectedKeys.size) { setActionError(new Error("Select at least one subtitle occurrence.")); return }
    if (!selectedSenses.size) { setActionError(new Error("Select at least one dictionary sense.")); return }
    setBusy(true); setActionError(null)
    try {
      if (!active) {
        const subtitleWords = [...selectedKeys].map((key) => { const found = tokenLookup.get(key); if (!found) throw new Error("A selected subtitle token no longer exists."); return tokenToSubtitleWordInput(found.token, found.cue) })
        const payload: CreateWordSenseMappingRequest = { section: section.id, senses: [...selectedSenses.keys()], subtitle_words: subtitleWords }
        await apiClient.post<WordSenseMapping, CreateWordSenseMappingRequest>("/api/courses/word-sense-mappings/", payload)
      } else {
        if (!sameIds(selectedSenses, originalSenseIds)) { const payload: UpdateWordSenseMappingRequest = { sense_ids: [...selectedSenses.keys()] }; await apiClient.patch(`/api/courses/word-sense-mappings/${active.id}/`, payload) }
        const originalByKey = new Map(active.subtitle_words.map((word) => [wordKey(word), word]))
        for (const key of selectedKeys) { if (originalByKey.has(key)) continue; const found = tokenLookup.get(key); if (!found) throw new Error("A selected subtitle token no longer exists."); const body: CreateSubtitleWordRequest = { mapping: active.id, ...tokenToSubtitleWordInput(found.token, found.cue) }; await apiClient.post("/api/courses/subtitle-words/", body) }
        for (const [key, word] of originalByKey) { if (!selectedKeys.has(key)) await apiClient.delete(`/api/courses/subtitle-words/${word.id}/`) }
      }
      await reload(); resetWorking()
    } catch (error) {
      let freshMappings: WordSenseMapping[] | null = null
      try { freshMappings = await reload() } catch { /* keep the original error */ }
      setActionError(new Error(active ? `Some mapping changes may already have been saved. The editor reloaded Django's current state. ${error instanceof Error ? error.message : ""}` : error instanceof Error ? error.message : "Unable to create mapping."))
      if (activeId && freshMappings) {
        const current = freshMappings.find((mapping) => mapping.id === activeId)
        if (current) {
          setActiveId(current.id)
          setSelectedKeys(new Set(current.subtitle_words.map(wordKey)))
          setSelectedSenses(new Map(current.senses.map((sense) => [sense.id, sense])))
          setSearch("")
          setResults([])
        } else {
          resetWorking()
        }
      }
    } finally { setBusy(false) }
  }
  async function deleteMapping() { if (!active || !window.confirm("Delete this mapping and all of its subtitle occurrences?")) return; setBusy(true); setActionError(null); try { await apiClient.delete(`/api/courses/word-sense-mappings/${active.id}/`); await reload(); resetWorking() } catch (error) { setActionError(error) } finally { setBusy(false) } }

  return <div className="grid gap-6 xl:grid-cols-[1fr_390px]"><div className="min-w-0 rounded-xl border bg-card"><div className="border-b p-4"><p className="text-sm text-muted-foreground">Click/tap exact tokens. Selected unmapped tokens can span cues. Clicking another mapped token opens that mapping.</p></div><div className="max-h-[720px] space-y-4 overflow-y-auto p-4">{effectiveLoadError ? <ApiErrorMessage error={effectiveLoadError} /> : cues.map((cue) => <div key={cue.cueId} className="rounded-lg border p-3"><div className="mb-2 flex items-center justify-between gap-3 text-xs text-muted-foreground"><span>Cue {cue.cueId}</span><span>{cue.startTime.toFixed(2)}–{cue.endTime.toFixed(2)}</span></div><div className="flex flex-wrap gap-x-1.5 gap-y-2 leading-8">{cue.tokens.map((token) => { const mapped = mappingIndex.get(token.key); const selected = selectedKeys.has(token.key); const belongsActive = mapped?.id === activeId; return <button key={token.key} type="button" onClick={() => clickToken(token)} className={cn("rounded px-1.5 py-0.5 text-sm ring-1 ring-inset transition", mapped ? mappingColor(mapped.id) : selected ? "bg-primary text-primary-foreground ring-primary" : "bg-muted/60 ring-border hover:bg-accent", belongsActive && "ring-2 ring-foreground")}>{token.word}</button> })}</div></div>)}</div></div><aside className="xl:sticky xl:top-4 xl:self-start"><div className="rounded-xl border bg-card p-5"><div className="flex items-start justify-between gap-3"><div><p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{active ? `Editing mapping #${active.id}` : "New mapping"}</p><h3 className="mt-1 font-semibold">{selectedKeys.size} selected occurrence{selectedKeys.size === 1 ? "" : "s"}</h3></div>{dirty ? <Button variant="ghost" size="icon" onClick={resetWorking} aria-label="Discard changes"><X className="size-4" /></Button> : null}</div><div className="mt-4 flex flex-wrap gap-2">{[...selectedSenses.values()].map((sense) => <button key={sense.id} onClick={() => toggleSense(sense)} className="rounded-full border px-2.5 py-1 text-xs hover:bg-accent">{sense.entry.word}: {sense.title} ×</button>)}</div><div className="mt-5"><label className="text-sm font-medium" htmlFor="sense-search">Find dictionary senses</label><div className="relative mt-2"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" /><Input id="sense-search" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" placeholder="word, title, definition…" /></div>{search.trim().length === 1 ? <p className="mt-1 text-xs text-muted-foreground">Type at least 2 characters.</p> : null}</div><div className="mt-3 max-h-64 space-y-2 overflow-y-auto">{searching ? <p className="flex items-center gap-2 text-sm text-muted-foreground"><LoaderCircle className="size-4 animate-spin" />Searching…</p> : results.map((sense) => <button type="button" key={sense.id} onClick={() => toggleSense(sense)} className={cn("w-full rounded-lg border p-3 text-left text-sm", selectedSenses.has(sense.id) && "border-primary bg-primary/5")}><span className="font-medium">{sense.entry.word}</span> <span className="italic text-muted-foreground">{sense.entry.part_of_speech}</span><span className="ml-2 text-xs text-muted-foreground">{sense.title}</span><span className="mt-1 block line-clamp-2">{sense.definition}</span></button>)}</div><div className="mt-4"><ApiErrorMessage error={actionError} /></div><div className="mt-5 flex flex-wrap gap-2"><Button disabled={busy || !selectedKeys.size || !selectedSenses.size} onClick={() => void save()}>{busy ? <LoaderCircle className="size-4 animate-spin" /> : null}{active ? "Save mapping" : `Map ${selectedKeys.size || "selected"} word${selectedKeys.size === 1 ? "" : "s"}`}</Button>{active ? <Button variant="destructive" disabled={busy} onClick={() => void deleteMapping()}><Trash2 className="size-4" />Delete mapping</Button> : null}</div><div className="mt-6 border-t pt-4 text-xs leading-5 text-muted-foreground"><p>Can’t find the needed sense? Open <Link href="/admin/dictionary" className="font-medium text-foreground underline">Dictionary</Link>{publicEnv.enableScraper ? <> or <Link href="/admin/dictionary/scrape" className="font-medium text-foreground underline">Scraper</Link></> : null}, create it, then return here.</p></div></div><div className="mt-3 flex flex-wrap gap-2">{mappings.map((mapping) => <button key={mapping.id} type="button" onClick={() => openMapping(mapping)} className={cn("rounded-full px-2.5 py-1 text-xs ring-1 ring-inset", mappingColor(mapping.id))}>#{mapping.id} · {mapping.senses[0]?.entry.word ?? "mapping"}</button>)}</div></aside></div>
}
