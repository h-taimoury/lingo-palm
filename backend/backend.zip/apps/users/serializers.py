from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    # Add full_name field for easy API display (READ-ONLY)
    # This uses the model's get_full_name() method implicitly or explicitly via a method field.
    full_name = serializers.SerializerMethodField()

    # # Define password explicitly as write-only for security and input control
    password = serializers.CharField(
        write_only=True,
        style={
            "input_type": "password"
        },  # This a piece of metadata specifically designed to instruct the Django Rest Framework Browsable API (and any other client that uses DRF's HTML form rendering logic) how to render the input field.
    )

    class Meta:
        model = User
        fields = (
            "id",
            "email",
            "first_name",
            "last_name",
            "full_name",
            "created_at",
            "password",
        )
        # Add read_only_fields for fields that shouldn't be modifiable via standard input
        read_only_fields = ["id", "full_name", "created_at"]
        # extra_kwargs = {"password": {"write_only": True}}

    def get_full_name(self, obj):
        # Uses the method defined in your User model
        return obj.get_full_name()

    def validate_password(self, value):
        # AUTH_PASSWORD_VALIDATORS in settings isn't applied automatically by DRF —
        # it only runs through Django's forms/management commands unless we call it
        # here ourselves. Without this, registration and /me/ password updates would
        # silently accept anything (e.g. "1").
        try:
            validate_password(value, user=self.instance)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages))
        return value

    ## Using the above validate_password method, the UserAttributeSimilarityValidator in AUTH_PASSWORD_VALIDATORS setting will not have any effect when registering a new user because self.instance is None. To fix this, we can override the validate method to create a temporary user instance for password validation.
    # def validate(self, attrs):
    #     password = attrs.get("password")
    #     if password is not None:
    #         temp_user = User(
    #             email=attrs.get("email", getattr(self.instance, "email", "")),
    #             first_name=attrs.get(
    #                 "first_name", getattr(self.instance, "first_name", "")
    #             ),
    #             last_name=attrs.get(
    #                 "last_name", getattr(self.instance, "last_name", "")
    #             ),
    #         )
    #         try:
    #             validate_password(password, user=temp_user)
    #         except DjangoValidationError as exc:
    #             raise serializers.ValidationError({"password": list(exc.messages)})
    #     return attrs

    # Create method (for POST/Registration)
    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user

    # Update method (for PUT/PATCH requests)

    # Option 1:
    def update(self, instance, validated_data):
        # 1. Safely retrieve the password and remove it from the data
        raw_password = validated_data.pop("password", None)

        # 2. If a password was provided, hash it using make_password()
        #    and put the HASHED value back into validated_data.
        if raw_password:
            validated_data["password"] = make_password(raw_password)

        # 3. Call the parent's update method. It sees "password" in validated_data
        #    and correctly saves the HASHED string, along with all other fields,
        #    in a single database call.
        instance = super().update(instance, validated_data)

        return instance

    # Option 2:
    # def update(self, instance, validated_data):
    #     # 1. Safely retrieve the password and remove it from the data
    #     password = validated_data.pop("password", None)

    #     # 2. Hash the password if provided and assign it to the instance,
    #     #    but DO NOT save the instance yet.
    #     if password:
    #         instance.set_password(password)

    #     # 3. Use the parent's update method to apply all remaining fields
    #     #    (first_name, last_name, etc.) AND perform the SINGLE database save.
    #     instance = super().update(instance, validated_data)

    #     return instance


class UserSerializerForAdmins(UserSerializer):
    """Admin-only serializer: used for /api/users/ list and detail views.

    Adds is_staff and is_active as writable fields — safe here because
    IsAdminUser already restricts these views to staff.
    """

    class Meta(UserSerializer.Meta):
        fields = UserSerializer.Meta.fields + ("is_staff", "is_active")
